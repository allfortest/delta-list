BANANA is the First Community-driven Asset Launchpad on Bitcoin，providing full-process asset management tools and services based on the BTC ecosystem.

BANANA provides full-process BRC20 asset management tools：

# BRC20 Launchpad
Ordinals inscription deployment
Inscription listed for trading
NFT Mining: Stake NFT and mine rewards

# $BNAN
Holders of $BNAN, the native token of the BANANA platform, will enjoy the fruits of developing the entire BANANA ecosystem.

$BNAN application scenarios

# Staking
Participate in $BNAN STAKING, and you will get more opportunities for lottery and whitelist activities within the BTC ecosystem.

# Integration
Events within the Bitcoin ecosystem involving $BNAN will earn points, serving as must-have tickets and market items.